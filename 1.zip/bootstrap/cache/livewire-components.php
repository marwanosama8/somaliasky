<?php return array (
  'category' => 'App\\Http\\Livewire\\Category',
  'chat' => 'App\\Http\\Livewire\\Chat',
  'city' => 'App\\Http\\Livewire\\City',
  'country-city-select' => 'App\\Http\\Livewire\\CountryCitySelect',
  'dashboard-statistics' => 'App\\Http\\Livewire\\DashboardStatistics',
  'files-viewer' => 'App\\Http\\Livewire\\FilesViewer',
  'home' => 'App\\Http\\Livewire\\Home',
  'rating' => 'App\\Http\\Livewire\\Rating',
  'upload-photo-with-preview' => 'App\\Http\\Livewire\\UploadPhotoWithPreview',
  'user-job' => 'App\\Http\\Livewire\\UserJob',
  'user-skill' => 'App\\Http\\Livewire\\UserSkill',
  'user-store' => 'App\\Http\\Livewire\\UserStore',
);