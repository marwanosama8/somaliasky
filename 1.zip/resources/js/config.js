const CONFIG = {
    API_URL_ROOT: 'https://somaliasky.test/',
  }
  
  export default CONFIG;