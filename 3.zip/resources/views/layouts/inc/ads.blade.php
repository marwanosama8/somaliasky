<!-- start of google-ads -->
<section class="ads">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="google-ads" style="padding-top: 110px; padding-bottom: 110px;">
                    <button>
                        <i class="fa fa-times"></i>
                    </button>
                    <img src="{{ asset('assets') }}/images/download.png">
                </div>
            </div>
            <div class="col-md-9">
                <div class="google-ads" style="padding-top: 110px; padding-bottom: 110px;">
                    <button>
                        <i class="fa fa-times"></i>
                    </button>
                    <img src="{{ asset('assets') }}/images/download.png">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end of google-ads -->
