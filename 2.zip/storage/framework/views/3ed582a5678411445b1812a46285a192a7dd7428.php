<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/cust-fonts.css')); ?>">
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive-font.css')); ?>">


    <?php if(app()->getLocale() == 'ar'): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.rtl.min.css')); ?>">
        
        <style>
            .spanIcon {
                right: 3% !important;
            }
        </style>
    <?php else: ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

        <style>
            .select-selected:after {
                left: 90% !important;
            }

            .select-selected.select-arrow-active:after {
                left: 90% !important;
                border-color: transparent #212529 transparent transparent !important;
            }

            .spanIcon {
                left: 3%;
            }
        </style>
    <?php endif; ?>

    <style>
        a:not([class^="btn"], [class^="navbar-brand"]) {
            color: <?php echo e($settings->main_color); ?> !important;
        }


        a:not([class^="navbar-brand"]) {
            font-weight: bold;
            /* font-size: 1rem */
        }

        .btn-primary {
            background-color: <?php echo e($settings->main_color); ?> !important;
            color: #fff !important;
        }

        .mainColor {
            color: <?php echo e($settings->main_color); ?> !important;
        }

        .mainBgColor {
            background: <?php echo e($settings->main_color); ?> !important;
            color: #fff !important;
        }


        /* The container must be positioned relative: */
        .custom-select {
            color: <?php echo e($settings->main_color); ?> !important;
        }

        .custom-select select {
            display: none;
            /*hide original SELECT element: */
        }

        .select-selected {
            color: <?php echo e($settings->main_color); ?> !important;
        }

        /* Style the arrow inside the select element: */
        .select-selected:after {
            border-color: #212529 transparent transparent transparent;
        }

        .select-selected.select-arrow-active:after {
            border-color: transparent transparent transparent #212529;
        }

        .spanIcon {
            color: <?php echo e($settings->main_color); ?> !important;
        }

        .is_featured {
            border: 3px solid #ffc800e3;
        }

        /* style the items (options), including the selected item: */
        .select-items div {
            color: #212529;
        }

        .select-items {
            width: 300px !important;
        }

        .select-selected {
            color: #212529;
        }

        .modal-backdrop.show {
            opacity: 0.3 !important;
        }

        .rad14 {
            border-radius: 14px !important;
        }

        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }

        .carousel-inner {
            height: 40vh;
        }

        .carousel-inner img {
            height: 40vh;
        }

        @media (max-width: 720px) {
            .carousel-inner {
                height: 50%;
            }

            .carousel-inner img {
                height: 30vh;
            }

            .spanIcon {
                top: 5% !important;
                <?php echo e(app()->getLocale() == 'ar' ? 'right: 8%' : 'left: 8%'); ?> !important;
            }
        }
        }
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('css/pace-theme-default.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fancybox.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/font-fileuploader.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/jquery.fileuploader.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/jquery.fileuploader-theme-dragdrop.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/flag-icons.min.css')); ?>">
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
    
    <style>
        body {
            /* height: 100%; */
            background: rgb(241, 241, 241);
        }

        .loader-wrapper {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #ecebeb;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999999999;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: <?php echo e($settings->main_color); ?>;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #2d6fc9;
        }

        *:not([class^="fa"]) {
            /* font-family: Cairo !important; */
            font-weight: bold
        }
    </style>
    <?php
        $page_title = '';
    ?>
    <?php echo $__env->make('seo.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->yieldContent('styles'); ?>
    <?php if(auth()->check()): ?>
        <?php
            if (session('seen_notifications') == null) {
                session(['seen_notifications' => 0]);
            }
            $notifications = auth()
                ->user()
                ->notifications()
                ->orderBy('created_at', 'DESC')
                ->limit(50)
                ->get();
            $unreadNotifications = auth()
                ->user()
                ->unreadNotifications()
                ->count();
        ?>
    <?php endif; ?>
    <?php if(app()->getLocale() == 'ar'): ?>
        <style>
            .notification-position {
                position: absolute !important;
                right: -279px !important;
                cursor: auto !important;
                z-index: 20000;
                width: 350px;
                height: 450px;
            }
        </style>
    <?php elseif(app()->getLocale() == 'en'): ?>
        <style>
            .notification-position {
                position: absolute !important;
                left: -285px !important;
                cursor: auto !important;
                z-index: 20000;
                width: 350px;
                height: 450px;
            }
        </style>
    <?php endif; ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/new/assets/style/style.css')); ?>">

</head>


<body class="">
    
    <?php if(flash()->message): ?>
        <div style="position: absolute;z-index: 4444444444444;left: 35px;top: 80px;max-width: calc(100% - 70px);padding: 16px 22px;border-radius: 7px;overflow: hidden;width: 273px;border-right: 8px solid #374b52;background: #2196f3;color: #fff;cursor: pointer;"
            onclick="$(this).slideUp();">
            <span class="fas fa-info-circle"></span> <?php echo e(flash()->message); ?>

        </div>
    <?php endif; ?>
    <div class="col-12 justify-content-end d-flex">
        <?php if($errors->any()): ?>
            <div class="col-12" style="position: absolute;top: 80px;left: 10px;">
                <?php echo implode(
                    '',
                    $errors->all(
                        '<div class="alert-click-hide alert alert-danger alert alert-danger col-9 col-xl-3 rounded-0 mb-1" style="position: fixed!important;z-index: 11;opacity:.9;left:25px;cursor:pointer;" onclick="$(this).fadeOut();">:message</div>',
                    ),
                ); ?>

            </div>
        <?php endif; ?>
    </div>
    <div id="app">
        <div class="loader-wrapper mainColor">
            <span class="loader text-center p-5">
                <img src="<?php echo e($settings->website_logo()); ?>" alt="" class="d-block mt-5" width="100%"
                    height="190">
                </span>
            </div>
        
            <?php echo $__env->make('layouts.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
                <?php echo $__env->make('layouts.inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                
                
                
            </div>
            <?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/fancybox.umd.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/pace.min.js')); ?>"></script>

    <script src="<?php echo e(asset('/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/jquery.fileuploader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/validatorjs.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/favicon_notification.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script>
    
    <script type="text/javascript">
        $(window).on('load', function() {
            $(".loader-wrapper").fadeOut("slow");
        });

        $(document).ready(function() {
            $('.select2-select').select2();
        });

        var x, i, j, l, ll, selElmnt, a, b, c;
        /* Look for any elements with the class "custom-select": */
        x = document.getElementsByClassName("custom-select");
        l = x.length;
        for (i = 0; i < l; i++) {
            selElmnt = x[i].getElementsByTagName("select")[0];
            ll = selElmnt.length;
            /* For each element, create a new DIV that will act as the selected item: */
            a = document.createElement("DIV");
            a.setAttribute("class", "select-selected");
            a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
            x[i].appendChild(a);
            /* For each element, create a new DIV that will contain the option list: */
            b = document.createElement("DIV");
            b.setAttribute("class", "select-items select-hide");
            for (j = 1; j < ll; j++) {
                /* For each option in the original select element,
                create a new DIV that will act as an option item: */
                c = document.createElement("DIV");
                c.innerHTML = selElmnt.options[j].innerHTML;
                c.addEventListener("click", function(e) {
                    /* When an item is clicked, update the original select box,
                    and the selected item: */
                    var y, i, k, s, h, sl, yl;
                    s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                    sl = s.length;
                    h = this.parentNode.previousSibling;
                    for (i = 0; i < sl; i++) {
                        if (s.options[i].innerHTML == this.innerHTML) {
                            s.selectedIndex = i;
                            h.innerHTML = this.innerHTML;
                            y = this.parentNode.getElementsByClassName("same-as-selected");
                            yl = y.length;
                            for (k = 0; k < yl; k++) {
                                y[k].removeAttribute("class");
                            }
                            this.setAttribute("class", "same-as-selected");
                            break;
                        }
                    }
                    h.click();
                });
                b.appendChild(c);
            }
            x[i].appendChild(b);
            a.addEventListener("click", function(e) {
                /* When the select box is clicked, close any other select boxes,
                and open/close the current select box: */
                e.stopPropagation();
                closeAllSelect(this);
                this.nextSibling.classList.toggle("select-hide");
                this.classList.toggle("select-arrow-active");
            });
        }

        function closeAllSelect(elmnt) {
            /* A function that will close all select boxes in the document,
            except the current select box: */
            var x, y, i, xl, yl, arrNo = [];
            x = document.getElementsByClassName("select-items");
            y = document.getElementsByClassName("select-selected");
            xl = x.length;
            yl = y.length;
            for (i = 0; i < yl; i++) {
                if (elmnt == y[i]) {
                    arrNo.push(i)
                } else {
                    y[i].classList.remove("select-arrow-active");
                }
            }
            for (i = 0; i < xl; i++) {
                if (arrNo.indexOf(i)) {
                    x[i].classList.add("select-hide");
                }
            }
        }

        /* If the user clicks anywhere outside the select box,
        then close all select boxes: */
        document.addEventListener("click", closeAllSelect);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous">
    </script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        window.livewire.on('update', () => {
            document.getElementById('chat').scroll(0, 100000000000000000000000000000);
        });
    </script>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('scripts'); ?>
    

</body>

</html>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/layouts/app.blade.php ENDPATH**/ ?>