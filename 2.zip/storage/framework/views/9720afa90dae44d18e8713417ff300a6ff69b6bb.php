<?php $__env->startSection('content'); ?>
    
    <div class="container mt-5" style="max-width: 550px">
        <div class="alert alert-danger" id="error" style="display: none;"></div>
        <h3><?php echo e(__('lang.sendOTP')); ?></h3>
        <div class="alert alert-success" id="successAuth" style="display: none;"></div>
        <form>
            <label><?php echo e(__('lang.addPhone')); ?></label>
            <input type="text" id="number" class="form-control" value="<?php echo e($number); ?>" placeholder="+91 ********">
            <div id="recaptcha-container"></div>
            <div class="row d-flex justify-content-center">

                <button type="button" class="btn btn-primary mt-3" onclick="sendOTP();"><?php echo e(__('lang.sendIt')); ?></button>
            </div>
        </form>

        <div class="mb-5 mt-5">
            <h3><?php echo e(__('lang.verfiyCode')); ?></h3>
            <div class="alert alert-success" id="successOtpAuth" style="display: none;"></div>
            <form>
                <input type="text" id="verification" class="form-control" placeholder="Verification code">
                <div class="row d-flex justify-content-center">
                    <button type="button" class="btn btn-primary mt-3" onclick="verify()"><?php echo e(__('lang.verfiyIt')); ?></button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.2.1/axios.min.js"
    integrity="sha512-zJYu9ICC+mWF3+dJ4QC34N9RA0OVS1XtPbnf6oXlvGrLGNB8egsEzu/5wgG90I61hOOKvcywoLzwNmPqGAdATA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    const firebaseConfig = {
        apiKey: "AIzaSyD6bK8eXFixLFgHBANFxZ2AcVdnXVadZs4",
        authDomain: "firstsooq-44f00.firebaseapp.com",
        projectId: "firstsooq-44f00",
        storageBucket: "firstsooq-44f00.appspot.com",
        messagingSenderId: "374147529857",
        appId: "1:374147529857:web:f5f71ac49bb2e40b17e180"
    };
    firebase.initializeApp(firebaseConfig);
</script>
<script type="text/javascript">
    window.onload = function() {
        render();
    };

    function render() {
        window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
        recaptchaVerifier.render();
    }

    function sendOTP() {
        var number = $("#number").val();
        firebase.auth().signInWithPhoneNumber(number, window.recaptchaVerifier).then(function(confirmationResult) {
            window.confirmationResult = confirmationResult;
            coderesult = confirmationResult;
            console.log(coderesult);
            $("#successAuth").text("Message sent");
            $("#successAuth").show();
        }).catch(function(error) {
            $("#error").text(error.message);
            $("#error").show();
        });
    }

    function verify() {
        var code = $("#verification").val();
        confirmationResult.confirm(code).then(function(result) {
            try {
                axios.get('save-otp')
                console.log('api done')
                window.location.replace("register");

            } catch (error) {
                console.log(error)
            }
        }).catch(function(error) {
            $("#error").text(error.message);
            $("#error").show();
        });
    }
</script>

<script src="<?php echo e(asset('/new/assets/js/flowbite.js')); ?>"></script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/auth/otp.blade.php ENDPATH**/ ?>