<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <section class="row text-center" style="margin: 20px 0">
            <h5 class="text-center text-lg-start"><?php echo e(__('lang.Categories')); ?></h5>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('front.categories.show', $category)); ?>" class="my-4 border-0 col-6 col-md-4 col-lg-2">
                    <img src="<?php echo e($category->image()); ?>" alt="<?php echo e($category->title); ?>" height="170" class="card-img-top rounded-3 mb-3">
                    <h6 class="font-1"><?php echo e($category->title); ?></h6>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/front/categories/index.blade.php ENDPATH**/ ?>