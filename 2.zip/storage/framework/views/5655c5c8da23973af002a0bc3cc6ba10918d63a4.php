<div class="container-fluid px-3 py-2 font-2 fw-bold">
    <form method="POST" action="<?php echo e(route('logout')); ?>" id="logout-form" class="d-none"><?php echo csrf_field(); ?></form>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand mainColor mx-3" href="/">
            
            <img src="<?php echo e($settings->website_logo()); ?>" alt="" width="180" height="60">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="far fa-bars font-4"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">

            <ul class="col-12 navbar-nav mb-2 mb-lg-0 text-center d-flex justify-content-between">
                <li class="nav-item dropdown font-2">

                    <?php if(auth()->check()): ?>
                        <ul class="dropdown-menu text-center">
                            <li class="nav-item pt-2"><a class="nav-link font-2"
                                    href="<?php echo e(route('front.profile')); ?>"><?php echo e(auth()->user()->name); ?></a></li>
                            <li class="nav-item pt-2"><a class="nav-link font-2"
                                    href="<?php echo e(route('front.chat')); ?>"><?php echo e(__('lang.messages')); ?>

                                    
                                </a>
                            </li>
                            <?php if(auth()->user()->store): ?>
                                <li class="nav-item pt-2"><a class="nav-link font-2"
                                        href="<?php echo e(route('front.store.my_store')); ?>"><?php echo e(auth()->user()->store->name); ?></a>
                                </li>
                            <?php else: ?>
                                <li class="nav-item pt-2"><a class="nav-link font-2"
                                        href="<?php echo e(route('front.store.my_store')); ?>"><?php echo e(__('lang.OpenStore')); ?></a></li>
                            <?php endif; ?>
                            <li class="nav-item pt-2"><a class="nav-link font-2" href="#"
                                    onclick="document.getElementById('logout-form').submit();"><?php echo e(__('lang.Logout')); ?></a>
                            </li>
                        </ul>
                    <?php endif; ?>
                </li>
                <li class="nav-item pt-2">
                    <a class="nav-link font-2 active" href="<?php echo e(route('home')); ?>"><?php echo e(__('lang.Go Home')); ?></a>
                </li>
                <li class="nav-item pt-2">
                    <a class="nav-link font-2"
                        href="<?php echo e(route('front.categories.index')); ?>"><?php echo e(__('lang.Categories')); ?></a>
                </li>

                <li class="nav-item dropdown pt-2">
                    <a class="nav-link dropdown-toggle font-2" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <span class="fal fa-language"></span>
                        <?php echo e(__('lang.Language')); ?>

                    </a>
                    <ul class="dropdown-menu text-center">
                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="nav-link" rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                    href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                    <?php echo e($properties['native']); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item pt-2">
                    <a class="nav-link font-2" href="<?php echo e(route('front.stores.index')); ?>"><?php echo e(__('lang.Stores')); ?></a>
                </li>

                <li class="nav-item pt-2">
                    <a class="nav-link font-2"
                        href="<?php echo e(route('front.announcements.index')); ?>"><?php echo e(__('lang.Announcements')); ?></a>
                </li>
                <?php if(!auth()->check()): ?>
                    <li class="nav-item pt-2"><a class="nav-link font-2"
                            href="<?php echo e(route('login')); ?>"><?php echo e(__('lang.Login')); ?></a></li>
                    <li class="nav-item pt-2"><a class="nav-link font-2"
                            href="<?php echo e(route('register')); ?>"><?php echo e(__('lang.Register')); ?></a>
                    </li>
                <?php else: ?>
                    <div class="btn-group" id="notificationDropdown">

                        <div class="col-12 px-0 d-flex justify-content-center align-items-center btn  "
                            style="width: 55px;height: 55px;" data-bs-toggle="dropdown" aria-expanded="false"
                            id="dropdown-notifications">
                            <span class="fal fa-bell font-3 d-inline-block"
                                style="color: #333;transform: rotate(15deg)"></span>
                            <span
                                style="position: absolute;min-width: 25px;min-height: 25px;
                        <?php if($unreadNotifications != 0): ?> display: inline-block;
                        <?php else: ?>
                        display: none; <?php endif; ?>
                        right: 0px;top: 0px;border-radius: 20px;background: #c00;color:#fff;font-size: 14px;"
                                id="dropdown-notifications-icon"><?php echo e($unreadNotifications); ?></span>

                        </div>
                        <div class="dropdown-menu py-0 rounded-0 border-0 shadow notification-position">
                            <div class="col-12 notifications-container" style="height:406px;overflow: auto;">
                                <?php if (isset($component)) { $__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5 = $component; } ?>
<?php $component = App\View\Components\Notifications::resolve(['notifications' => $notifications] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notifications'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Notifications::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5)): ?>
<?php $component = $__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5; ?>
<?php unset($__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5); ?>
<?php endif; ?>
                            </div>
                            <div class="col-12 d-flex border-top">
                                <a href="<?php echo e(route('front.notifications.index')); ?>" class="d-block py-2 px-3 ">
                                    <div class="col-12 align-items-center">
                                        <span class="fal fa-bells"></span> عرض كل الإشعارات
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                


            </ul>

        </div>


    </nav>
    <div class="d-flex container justify-content-between align-items-center">
        <a href="#" style="background: #722f37 !important;
                            color: white !important;"
            class='d-flex text-light py-3 px-2 rounded justify-content-between align-items-center  gap-3 '>
            <h6 class="font-bold"> <?php echo e(__('lang.customer_number')); ?>

            </h6>
            <h6 class="font-bold"><?php echo e(\App\Models\Counter::latest()->pluck('views')[0]); ?></h6>
            <h6 class=""><img src="<?php echo e(asset('new/assets/imgs/analysis-svgrepo-com.png')); ?>" alt=""
                    style="border-radius: 50%" width="50" height="30" srcset=""></h6>
        </a>
        <a href="<?php echo e(route('front.store.my_store')); ?>"
            style="background: #000000 !important;
        color: white !important;"
            class=" font-bold rounded py-3 px-2 text-white ">
            <?php echo e(__('lang.OpenStore')); ?>

        </a>
        <a href="<?php echo e(route('front.announcements.create')); ?>"
            style="background: #722f37 !important;
        color: white !important;"
            class=" font-bold rounded py-3 px-2 text-white ">
            <?php echo e(__('lang.AddAnnouncement')); ?>

        </a>
        <div class="flex items-center">
            <h6 class="font-bold">

                <?php echo e(__('lang.Hello!')); ?>

                <span> </span>
                <span><?php echo e(auth()->user() ? auth()->user()->name : 'شادي'); ?></span>
            </h6>
        </div>
        <div class="flex items-center  md:w-[4%]">
            <li class="nav-item dropdown font-2 d-block">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    
                    <img src="<?php echo e(auth()->check()? auth()->user()->getUserAvatar(): asset('images/default/avatar.png')); ?>"
                        alt="" style="border-radius: 50%" width="40" height="40">
                </a>
                <?php if(auth()->check()): ?>
                    <ul class="dropdown-menu text-center">
                        <li class="nav-item pt-2"><a class="nav-link font-2"
                                href="<?php echo e(route('front.profile')); ?>"><?php echo e(auth()->user()->name); ?></a></li>
                        <li class="nav-item pt-2"><a class="nav-link font-2"
                                href="<?php echo e(route('front.chat')); ?>"><?php echo e(__('lang.messages')); ?>

                                
                            </a>
                        </li>
                        <?php if(auth()->user()->store): ?>
                            <li class="nav-item pt-2"><a class="nav-link font-2"
                                    href="<?php echo e(route('front.store.my_store')); ?>"><?php echo e(auth()->user()->store->name); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item pt-2"><a class="nav-link font-2"
                                    href="<?php echo e(route('front.store.my_store')); ?>"><?php echo e(__('lang.OpenStore')); ?></a></li>
                        <?php endif; ?>
                        <li class="nav-item pt-2"><a class="nav-link font-2" href="#"
                                onclick="document.getElementById('logout-form').submit();"><?php echo e(__('lang.Logout')); ?></a>
                        </li>
                    </ul>
                <?php endif; ?>
            </li>
        </div>
    </div>
    <?php if(!auth()->check()): ?>
        
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content" style="border-radius: 14px">
                    <form method="POST" class="p-2" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="text-center pb-2 pt-5">
                            <img src="<?php echo e($settings->website_logo()); ?>" alt="" width="120"
                                height="60">
                            
                            <p class="py-1"><?php echo e(__('lang.login')); ?></p>
                        </div>
                        <div class="form-group row pb-1">

                            <div class="col-12">
                                <label for="email"
                                    class="col-form-label text-md-end"><?php echo e(__('lang.email')); ?></label>
                                <input id="email" type="email"
                                    class="rad14 form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row pb-1">

                            <div class="col-12">
                                <label for="password"
                                    class="col-form-label text-md-end"><?php echo e(__('lang.password')); ?></label>
                                <input id="password" type="password"
                                    class="rad14 form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    required autocomplete="current-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row pb-3 text-right">
                            <div class="col-12">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                    <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="remember">
                                    <?php echo e(__('lang.remember_me')); ?>

                                </label>
                            </div>
                        </div>


                        <div class="form-group row pb-3 px-5 text-center">
                            <button type="submit" class="btn mainBgColor">
                                <?php echo e(__('lang.login')); ?>

                            </button>
                            <div class="col-md-12">

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('lang.forget_your_password')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/layouts/inc/nav.blade.php ENDPATH**/ ?>