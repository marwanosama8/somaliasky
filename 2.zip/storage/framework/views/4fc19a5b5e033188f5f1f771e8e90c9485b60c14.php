<div class="row p-0">
    <div class="col-12 col-lg-6 my-2">
        <div class="col-12">
            <?php echo e(__('lang.Country')); ?>

        </div>
        <div class="col-12 pt-2">
            <select class="form-control rounded-3" wire:change="City()" wire:load="City()" name="Country" wire:model="country_id" required>
                <option value="" selected><?php echo e(__('lang.Country')); ?></option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country->id); ?>" <?php if(old('country_id')==$country->id): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php if($cities): ?>
    <div class="col-12 col-lg-6 my-2">
        <div class="col-12">
            <?php echo e(__('lang.City')); ?>

        </div>
        <div class="col-12 pt-2">
            <select class="form-control rounded-3" wire:model="city_id" name="City" required>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city->id); ?>" <?php if(old('City')==$city->id): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/livewire/city.blade.php ENDPATH**/ ?>