<footer class="mainBgColor text-center justify-content-center w-100 mb-0"
    style="position: static; bottom: 0;margin-top: 100px">

    <div class="container">
        <div class="row justify-content-center py-3" style="align-items: center;">
            <div class="col-12 col-md-4">
                <!-- Section: Social media -->
                <section class="text-center text-light mb-sm-2">
                    <!-- Facebook -->
                    <a class="btn text-white btn-floating m-1" style="background-color: #3b5998;"
                        href="<?php echo e($settings->facebook_link); ?>" role="button"><i class="fab fa-facebook-f"></i></a>

                    <!-- Twitter -->
                    <a class="btn text-white btn-floating m-1" style="background-color: #55acee;"
                        href="<?php echo e($settings->twitter_link); ?>" role="button"><i class="fab fa-twitter"></i></a>


                    <!-- Instagram -->
                    <a class="btn text-white btn-floating m-1" style="background-color: #ac2bac;"
                        href="<?php echo e($settings->instagram_link); ?>" role="button"><i class="fab fa-instagram"></i></a>

                </section>
                <!-- Section: Social media -->
            </div>
            <div class="col-12 col-md-4">
                <!-- Copyright -->
                <div class="text-center text-light">
                    Copyright <?php echo e(date('Y')); ?> © <?php echo e(env('APP_NAME')); ?>

                </div>
                <!-- Copyright -->
            </div>
            <div class="col-12 col-md-4">
                <!-- Section: Social media -->
                <section class="text-center text-light mb-sm-2">
                    <!-- Facebook -->
                    <a class="text-light m-1" style="color: #fff !important" href="<?php echo e(route('contact')); ?>"
                        role="button"><?php echo e(__('lang.contact')); ?></a>

                    <a class="text-light m-1" style="color: #fff !important" href="<?php echo e(route('about')); ?>"
                        role="button"><?php echo e(__('lang.about')); ?></a>

                    <a class="text-light m-1" style="color: #fff !important" href="<?php echo e(route('privacy_policy')); ?>"
                        role="button"><?php echo e(__('lang.Privacy Policy')); ?></a>
                    
                </section>
                <!-- Section: Social media -->
            </div>
        </div>
    </div>

</footer>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/layouts/inc/footer.blade.php ENDPATH**/ ?>