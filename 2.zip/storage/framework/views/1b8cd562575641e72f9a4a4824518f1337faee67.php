<?php $__env->startSection('styles'); ?>
    <style>
        .search,
        nav {
            display: none !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <center>
        <div class="tw-m-auto">
            <h3 class="tw-py-10 tw-font-bold tw-text-xl">إنشاء حساب / تسجيل دخول</h3>
            <form method="post" action="<?php echo e(route('login-form')); ?>">
                <?php echo csrf_field(); ?>
                 <div id="app" class="tw-flex tw-w-2/3 md:tw-w-1/3" dir="ltr">
                    <country-selection :countries='<?php echo e(App\Models\Country::get()); ?>'></country-selection>
                    <label for="states" class="tw-sr-only">Choose a state</label>
                    <input type="text"
                        class="tw-bg-gray-50 tw-text-center tw-border tw-border-gray-300 tw-text-gray-900 tw-text-sm tw-rounded-r-lg tw-border-l-gray-100 dark:tw-border-l-gray-700 tw-border-l-2 focus:tw-ring-blue-500 focus:tw-border-blue-500 tw-block tw-w-full p-2.5 dark:tw-bg-gray-700 dark:tw-border-gray-600 dark:tw-placeholder-gray-400 dark:tw-text-white dark:focus:tw-ring-blue-500 dark:focus:tw-border-blue-500"
                        name="phone" placeholder="<?php echo e(__('lang.phone')); ?>" id="">
                </div>
                <button type="submit"
                    class="tw-my-10 tw-py-3 tw-px-6 tw-bg-primary tw-font-bold tw-text-white tw-rounded-md tw-w-1/2 md:tw-w-1/3">
                    تسجيل الدخول
                </button>
            </form>


            <h3 class=" md:tw-w-[28%] tw-font-bold">
                باستخدامك السوق الدباسي أنت توافق على اتفاقية الاستخدام وسياسة المحتوى شاهد المزيد على
            </h3>
        </div>
    </center>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/new/assets/js/flowbite.js')); ?>"></script>
                <script src="<?php echo e(asset('/dist/js/app.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/auth/login.blade.php ENDPATH**/ ?>