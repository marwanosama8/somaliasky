<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <div class="card my-4">

            <div id="carouselExampleIndicators" class="carousel slide carousel-dark carousel-fade" data-bs-ride="true">
                <div class="carousel-indicators mb-2">
                    <?php $__currentLoopData = App\Models\Slider::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" data-bs-target="#carouselExampleIndicators"
                            data-bs-slide-to="<?php echo e($loop->index); ?>" style="border-radius: 50%; height:0px; width: 15px;"
                            class="<?php echo e($loop->first ? 'active' : ''); ?> mainBgColor" aria-current="true"
                            aria-label="Slide <?php echo e($loop->iteration); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="carousel-inner">
                    <?php $__currentLoopData = App\Models\Slider::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                            <img src="<?php echo e($slider->image()); ?>" width="100%" alt="<?php echo e($slider->link); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>

        
        <section class="row justify-content-lg-between text-sm-center">
            <div class="col-12 col-md-4 mb-5">
                <h5 class="text-center text-lg-start"><?php echo e(__('lang.Categories')); ?></h5>
            </div>
            <div class="col-12 col-md-4 col-lg-2 justify-content-lg-end mb-4">
                <a href="<?php echo e(route('front.categories.index')); ?>" class="btn btn-block w-100 mainBgColor rad14">
                    <?php echo e(__('lang.Show All')); ?>

                    <?php if(app()->getLocale() == 'ar'): ?>
                        <span class="fas fa-arrow-left"></span>
                    <?php else: ?>
                        <span class="fas fa-arrow-right"></span>
                    <?php endif; ?>
                </a>
            </div>
        </section>
        <section class="row text-center" style="margin: 50px 0;">
            <?php $__currentLoopData = $categories->where('parent_id', null)->take(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('front.categories.show', $category)); ?>"
                    class="mb-4 border-0 col-6 col-md-4 col-lg-2 h-hv-50">
                    <img src="<?php echo e($category->image_path); ?>" alt="<?php echo e($category->title); ?>"
                        class="card-img-top rounded-3 mb-3" width="100%" height="80%">
                    <h6><?php echo e($category->title); ?></h6>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
        <?php $__empty_1 = true; $__currentLoopData = $announcementsCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($is_featured->where('category_id', $category->id)->count() != 0 ||
                $announcements->where('category_id', $category->id)->count() != 0): ?>
                <section class="row justify-content-lg-between text-sm-center">
                    <div class="col-12 col-md-4 mb-4">
                        <h5 class="text-center text-lg-start">
                            <img src="<?php echo e($category->image_path); ?>" width="60" height="60" alt=""
                                class="rounded-circle">
                            <?php echo e(($category->category ? $category->category->title : '') . ' - ' . $category->title); ?>

                        </h5>
                    </div>
                    <div class="col-12 col-md-4 col-lg-2">
                        <a href="<?php echo e(route('front.categories.show', $category)); ?>"
                            class="btn btn-block w-100 mainBgColor rad14">
                            <?php echo e(__('lang.Show All')); ?>

                            <?php if(app()->getLocale() == 'ar'): ?>
                                <span class="fas fa-arrow-left"></span>
                            <?php else: ?>
                                <span class="fas fa-arrow-right"></span>
                            <?php endif; ?>
                        </a>
                    </div>
                </section>
            <section class="row py-4">
                
                <?php $__currentLoopData = $is_featured->where('category_id', $category->id)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anncmentf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($anncmentf->getTranslation('title', app()->getLocale())): ?>
                        <div class="col-12 col-lg-4 mb-4">
                            <div class="card rad14 border-warning border-1">
                                <div class="row">
                                    <div class="col-6 col-md-5 rad14 py-4">
                                        <a href="<?php echo e(route('front.announcements.show', $anncmentf)); ?>">
                                            <img src="<?php echo e($anncmentf->imagesArray()[0] ?? env('DEFAULT_IMAGE')); ?>"
                                                class="rad14" width="100%" height="150vh" alt="<?php echo e($anncmentf->title); ?>">
                                        </a>
                                    </div>
                                    <div class="col-6 col-md-7">
                                        <div class="card-body">
                                            <p class="text-truncate font-2" title="<?php echo e($anncmentf->title); ?>">
                                                <a href="<?php echo e(route('front.announcements.show', $anncmentf)); ?>">
                                                    <?php echo e($anncmentf->title); ?>

                                                </a>
                                            </p>
                                            <h6 class="font-1">
                                                <p class="mb-2 text-truncate">
                                                    <?php echo e($anncmentf->city->name . ' - ' . $anncmentf->city->country->name); ?>

                                                </p>
                                                <p class="text-truncate ">
                                                    <?php echo e(($anncmentf->category->category ? $anncmentf->category->category->title : '') . ' - ' . $anncmentf->category->title); ?>

                                                </p>
                                            </h6>
                                            <div class="col-12 text-end">
                                                <p>
                                                    <?php echo e(__('lang.price') . ' ' . $anncmentf->price . ' ' . ($anncmentf->currency->name ?? 'rs')); ?>

                                                </p>
                                                <?php if(auth()->check() && auth()->user()->id !== $anncmentf->user->id): ?>
                                                    <a href="<?php echo e(route('front.chat', ['user_id' => $anncmentf->user->id, 'announcement_number' => $anncmentf->number])); ?>"
                                                        class="btn m-0 btn-sm rad14 <?php echo e($anncmentf->is_featured > 0 ? 'btn-warning text-light' : 'mainBgColor'); ?>"><?php echo e(__('lang.Send')); ?></a>
                                                <?php else: ?>
                                                    <a href="#"
                                                        class="btn m-0 btn-sm rad14 <?php echo e($anncmentf->is_featured > 0 ? 'btn-warning text-light' : 'mainBgColor'); ?>"><?php echo e(__('lang.Send')); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $announcements->where('category_id', $category->id)->take(9); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anncment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($anncment->getTranslation('title', app()->getLocale())): ?>
                        <div class="col-12 col-lg-4 mb-4">
                            <div class="card rad14">
                                <div class="row">
                                    <div class="col-6 col-md-5 rad14 py-4">
                                        <a href="<?php echo e(route('front.announcements.show', $anncment)); ?>">
                                            <img src="<?php echo e($anncment->imagesArray()[0] ?? env('DEFAULT_IMAGE')); ?>"
                                                class="rad14" width="100%" height="150vh" alt="<?php echo e($anncment->title); ?>">
                                        </a>
                                    </div>
                                    <div class="col-6 col-md-7">
                                        <div class="card-body">
                                            <p class="text-truncate font-2" title="<?php echo e($anncment->title); ?>">
                                                <a href="<?php echo e(route('front.announcements.show', $anncment)); ?>">
                                                    <?php echo e($anncment->title); ?>

                                                </a>
                                            </p>
                                            <h6 class="font-1">
                                                <p class="mb-2 text-truncate">
                                                    <?php echo e($anncment->city->name . ' - ' . $anncment->city->country->name); ?>

                                                </p>
                                                <p class="text-truncate ">
                                                    <?php echo e(($anncment->category->category ? $anncment->category->category->title : '') . ' - ' . $anncment->category->title); ?>

                                                </p>
                                            </h6>
                                            <div class="col-12 text-end">
                                                <p>
                                                    <?php echo e(__('lang.price') . ' ' . $anncment->price . ' ' . ($anncment->currency->name ?? 'rs')); ?>

                                                </p>
                                                <?php if(auth()->check() && auth()->user()->id !== $anncment->user->id): ?>
                                                    <a href="<?php echo e(route('front.chat', ['user_id' => $anncment->user->id, 'announcement_number' => $anncment->number])); ?>"
                                                        class="btn m-0 btn-sm rad14 <?php echo e($anncment->is_featured > 0 ? 'btn-warning text-light' : 'mainBgColor'); ?>"><?php echo e(__('lang.Send')); ?></a>
                                                <?php else: ?>
                                                    <a href="#"
                                                        class="btn m-0 btn-sm rad14 <?php echo e($anncment->is_featured > 0 ? 'btn-warning text-light' : 'mainBgColor'); ?>"><?php echo e(__('lang.Send')); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <section class="h-100">
                <h4><?php echo e(__('lang.No Data')); ?></h4>
            </section>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/front/index.blade.php ENDPATH**/ ?>