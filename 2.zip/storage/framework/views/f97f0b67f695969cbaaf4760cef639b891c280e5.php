<div class="container">
    <form action="" method="get">
        <div class="card rad14 search bg-transparent">
            <div class="row py-1">
                <div class="col-12 col-lg-3 mb-3 mb-lg-0">
                    <div class="custom-select">
                        <span class='spanIcon fas fa-th-large font-2'></span>
                        <select name="Category">
                            <option value=""><?php echo e(__('lang.Select Category')); ?></option>
                            <option value=""><?php echo e(__('lang.Select Category')); ?></option>
                            <?php $__currentLoopData = $categories->where('parent_id', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(request()->Category == $category->id ? 'selected' : ''); ?>

                                    value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('country-city-select', ['countryId' => request()->country,'cityId' => request()->city,'country_id' => request()->country,'city_id' => request()->city])->html();
} elseif ($_instance->childHasBeenRendered('H024F8W')) {
    $componentId = $_instance->getRenderedChildComponentId('H024F8W');
    $componentTag = $_instance->getRenderedChildComponentTagName('H024F8W');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('H024F8W');
} else {
    $response = \Livewire\Livewire::mount('country-city-select', ['countryId' => request()->country,'cityId' => request()->city,'country_id' => request()->country,'city_id' => request()->city]);
    $html = $response->html();
    $_instance->logRenderedChild('H024F8W', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <div class="col-12 col-lg-3 mb-3 mb-lg-0">
                    <div class="d-flex">
                        <input class="form-control" type="text" autocomplete="off"
                            placeholder="<?php echo e(__('lang.Search')); ?>" value="<?php echo e(request()->q); ?>" name="q">
                        <button class="btn mainBgColor"
                            style="border-radius: <?php echo e(app()->getLocale() == 'ar' ? '15px 0 0 15px' : '0 15px 15px 0'); ?>"
                            type="submit"><span class="fas fa-search"></span></button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/layouts/inc/search.blade.php ENDPATH**/ ?>