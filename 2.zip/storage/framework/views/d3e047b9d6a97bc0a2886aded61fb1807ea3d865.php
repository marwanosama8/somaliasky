<div class="row p-0">
    <div class="col-12 col-lg-6 my-2">
        <div class="col-12">
            <?php echo e(__('lang.Select Category')); ?>

        </div>
        <div class="col-12 pt-2">
            <select class="form-control rounded-3" wire:change="subCategory()" wire:model="category_id" name="category_id"
                required>
                <option value="" selected><?php echo e(__('lang.Select Category')); ?></option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php if(old('category_id') == $category->id): ?> selected <?php endif; ?>>
                        <?php echo e($category->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php if($subcategories): ?>
        <div class="col-12 col-lg-6 my-2">
            <div class="col-12">
                <?php echo e(__('lang.Select Category')); ?>

            </div>
            <div class="col-12 pt-2">
                <select class="form-control rounded-3" wire:model="subcategory_id" name="Category" wire:change="att()"
                    required>
                    <option value="" selected><?php echo e(__('lang.Select Category')); ?></option>
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subcategory->id); ?>" <?php if(old('Category') == $subcategory->id): ?> selected <?php endif; ?>>
                            <?php echo e($subcategory->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-12 col-lg-12 mt-sm-3 repeater">

            <div data-repeater-list="announcement_attributes" class="py-2 row">
                <?php $__empty_1 = true; $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div data-repeater-item class="col-6">
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <?php $__currentLoopData = config('laravellocalization.supportedLocales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item mx-auto" role="presentation">
                                    <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>"
                                        id="pills2-<?php echo e($key); ?>-tab" data-bs-toggle="pill"
                                        href="#pills2-<?php echo e($key); ?>" role="tab"
                                        aria-controls="pills2-<?php echo e($key); ?>"
                                        aria-selected="true"><?php echo e($lang['native']); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="tab-content" id="pills2-tabContent">
                            <?php $__currentLoopData = config('laravellocalization.supportedLocales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade show <?php echo e($loop->first ? 'active' : ''); ?>"
                                    id="pills2-<?php echo e($key2); ?>" role="tabpanel"
                                    aria-labelledby="pills2-<?php echo e($key2); ?>-tab">
                                    <label for="attrr"><?php echo e($attr->getTranslation('name', $key2)); ?></label>
                                    <input hidden type="hidden" name="attr" value="<?php echo e($attr->id); ?>" />
                                    <input id="attrr" class="form-control mb-3" type="text"
                                        name="[<?php echo e($key2); ?>.value]"
                                        placeholder="<?php echo e($attr->getTranslation('name', $key2)); ?>"
                                        value="<?php echo e($catAttributes->AnnouncementAttribute[$loop->index]->value ?? ''); ?>" />


                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/livewire/category.blade.php ENDPATH**/ ?>