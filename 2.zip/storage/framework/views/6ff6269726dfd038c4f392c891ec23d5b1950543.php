<div>
    <div class="mx-auto mt-0 mb-2 border-2 position-relative">
        <?php if($photo): ?>
            <img src="<?php echo e($photo->temporaryUrl()); ?>" alt="" class="mx-auto border border-5 mainBgColor" style="border-radius: 50%" width="190" height="190">
        <?php elseif($store): ?>
            <img src="<?php echo e($store->avatar_image()); ?>" alt="" class="mx-auto border border-5 mainBgColor" style="border-radius: 50%" width="190" height="190">
        <?php elseif($profile): ?>
            <img src="<?php echo e($profile->getUserAvatar()); ?>" alt="" class="mx-auto border border-5 mainBgColor" style="border-radius: 50%" width="190" height="190">
        <?php else: ?>
            <img src="<?php echo e(env('DEFAULT_IMAGE')); ?>" alt="" class="mx-auto border border-5 mainBgColor" style="border-radius: 50%" width="190" height="190">
        <?php endif; ?>
        <label for="photo" class="position-absolute mainBgColor rounded-circle p-1 pl-5" style="width: 30px; height : 30px;top: 75%;<?php echo e(app()->getLocale() == 'ar' ? 'left : 46.4%' : 'right: 46%'); ?>;">
            <span class="far fa-edit fw-500"></span>
        </label>
    </div>
    <div class="d-block">
        <input type="file" id="photo" hidden name="Avatar" wire:model="photo">
    </div>

    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/livewire/upload-photo-with-preview.blade.php ENDPATH**/ ?>