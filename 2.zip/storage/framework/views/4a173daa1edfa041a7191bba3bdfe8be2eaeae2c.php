<?php $__env->startSection('styles'); ?>
<style>
    .search{
        display:none !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row pt-5">
        <div class="col-12" style="">
            <div class="col-12">
                <form method="POST" action="<?php echo e(route('front.store.my_store_save')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-8 pt-5">
                            <h3 class="mb-3 mainColor"><?php echo e(__('lang.OpenStore')); ?></h3>
                            <p class="mb-5"><?php echo e(__('lang.Store msg')); ?></p>
                        </div>
                        <div class="col-4 mt-0 mb-5 text-center">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('upload-photo-with-preview', [])->html();
} elseif ($_instance->childHasBeenRendered('v6AxJdU')) {
    $componentId = $_instance->getRenderedChildComponentId('v6AxJdU');
    $componentTag = $_instance->getRenderedChildComponentTagName('v6AxJdU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('v6AxJdU');
} else {
    $response = \Livewire\Livewire::mount('upload-photo-with-preview', []);
    $html = $response->html();
    $_instance->logRenderedChild('v6AxJdU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <?php echo e(__('lang.Add') . ' ' .__('lang.Store Logo')); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group row pb-3">
                                <div class="col-12 col-md-4">
                                    <label for="Name" class="col-form-label text-md-end"><?php echo e(__('lang.Store Name')); ?></label>
                                    <input id="Name" type="text" placeholder="<?php echo e(__('lang.Store Name')); ?>" class="form-control rounded-3 <?php $__errorArgs = ['Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Name" value="<?php echo e(old('Name')); ?>" required>
                                    <?php $__errorArgs = ['Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-8 px-0">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category', [])->html();
} elseif ($_instance->childHasBeenRendered('O93mPTd')) {
    $componentId = $_instance->getRenderedChildComponentId('O93mPTd');
    $componentTag = $_instance->getRenderedChildComponentTagName('O93mPTd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('O93mPTd');
} else {
    $response = \Livewire\Livewire::mount('category', []);
    $html = $response->html();
    $_instance->logRenderedChild('O93mPTd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                            <div class="form-group row pb-3">
                                <div class="col-8 px-0">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('city', [])->html();
} elseif ($_instance->childHasBeenRendered('3THYCne')) {
    $componentId = $_instance->getRenderedChildComponentId('3THYCne');
    $componentTag = $_instance->getRenderedChildComponentTagName('3THYCne');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3THYCne');
} else {
    $response = \Livewire\Livewire::mount('city', []);
    $html = $response->html();
    $_instance->logRenderedChild('3THYCne', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label for="Location" class="col-form-label text-md-end"><?php echo e(__('lang.Store location')); ?></label>
                                    <input id="Location" type="text" placeholder="<?php echo e(__('lang.Store location')); ?>" class="form-control rounded-3 <?php $__errorArgs = ['Location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Location" value="<?php echo e(old('Location')); ?>" required>
                                    <?php $__errorArgs = ['Location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row pb-3">
                                <div class="col-12 col-md-4">
                                    <label for="photos" class="col-form-label text-md-end"><?php echo e(__('lang.Cover')); ?></label>
                                    <div class="col-12 mt-2" style="overflow: hidden">
                                        <div class="col-12 px-0" id="file-uploader-nafezly-second">
                                            <input type="hidden" disabled class="file-uploader-uploaded-files">
                                            <input name="file" type="file" class="file-uploader-files"
                                                data-fileuploader-files="" style="opacity: 0" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label for="Description" class="col-form-label text-md-end"><?php echo e(__('lang.Store Desc')); ?></label>
                                    <textarea id="Description" rows="6" placeholder="<?php echo e(__('lang.Store Desc')); ?>" class="form-control rounded-3 <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Description" required><?php echo e(old('Description')); ?></textarea>
                                    <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 col-md-4 px-4 text-center pt-5 mb-5">
                                    <div class="pt-4">
                                        <label for="accept" class="mb-4">
                                            <input type="checkbox" id="accept" required name="accept_rules">
                                            <a class="text-primary" href="#"><?php echo e(__('lang.I accept the terms of service')); ?></a>
                                        </label>
                                        <button type="submit" class="btn w-75 rad14 mainBgColor">
                                            <?php echo e(__('lang.Store Button')); ?>

                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('admin.templates.dropzone', [
        'selector' => '#file-uploader-nafezly-second',
        'url' => route('front.upload.file'),
        'method' => 'POST',
        'remove_url' => route('front.upload.remove-file'),
        'remove_method' => 'POST',
        'enable_selector_after_upload' => '#submitEvaluation',
        'max_files' => 1,
        'max_file_size' => 1024,
        'accepted_files' => "['image/*']",
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/front/stores/open-store.blade.php ENDPATH**/ ?>