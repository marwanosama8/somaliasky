<div class="col-12 col-lg-6">
    <div class="row">

        <div class="col-12 col-lg-6 mb-3 mb-lg-0">
            <div class="custom-select2">
                
                <select wire:change="City()" class="form-control" name="country" wire:model="country_id" style="border-radius: 20px;padding: 10px 40px;color: #722F37;">
                    <option value=""><?php echo e(__('lang.Country')); ?></option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(request()->country == $country->id ? 'selected' : ''); ?> value="<?php echo e($country->id); ?>">
                            <?php echo e($country->name_ar); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-12 col-lg-6 mb-3 mb-lg-0">
            <div class="custom-select2">
                
                <select name="city" class="form-control" wire:model="city_id" style="border-radius: 20px;padding: 10px 40px;color: #722F37;">
                    <option value=""><?php echo e(__('lang.Select City')); ?></option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(request()->city == $city->id ? 'selected' : ''); ?> value="<?php echo e($city->id); ?>">
                            <?php echo e($city->name_ar); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/marwan/Sites/SomaliaSky/resources/views/livewire/country-city-select.blade.php ENDPATH**/ ?>